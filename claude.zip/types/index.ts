/**
 * Type definitions for Shelbyflix
 */

export interface VideoMetadata {
  videoId: string;
  title: string;
  description: string;
  shelbyUrl: string;
  uploader: string;
  requiredToken: string;
  price: number;
  timestamp: number;
  views: number;
  thumbnailUrl?: string;
  duration?: number;
}

export interface ShelbyUploadResponse {
  success: boolean;
  blobId?: string;
  shelbyUrl?: string;
  error?: string;
}

export interface UploadProgress {
  percent: number;
  stage: 'preparing' | 'uploading' | 'processing' | 'complete';
  message: string;
}

export interface VideoStorageProvider {
  upload(file: File, metadata: any): Promise<any>;
  download(blobId: string): Promise<Blob>;
  delete(blobId: string): Promise<boolean>;
}

export interface GalleryFilters {
  search: string;
  sortBy: 'newest' | 'oldest' | 'popular';
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  message: string;
  duration?: number;
}
