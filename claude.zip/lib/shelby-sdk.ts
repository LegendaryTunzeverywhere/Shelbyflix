/**
 * ============================================================================
 * SHELBY PROTOCOL SDK INTEGRATION
 * ============================================================================
 * 
 * Official Documentation: https://docs.shelby.xyz/sdks/typescript/browser
 */

import type { VideoMetadata } from '@/types';

// ============================================================================
// CONFIGURATION
// ============================================================================

const SHELBY_API_KEY = process.env.NEXT_PUBLIC_SHELBY_API_KEY || 
  process.env.SHELBY_API_KEY || '';

// Initialize Shelby SDK - Load dynamically to handle SDK availability
let shelby: any = null;

async function initializeShelby() {
  if (shelby) return shelby;
  
  try {
    // Try to dynamically import the SDK
    const ShelbyModule = await import('@shelby-protocol/sdk/browser').catch(() => null);
    
    if (!ShelbyModule) {
      throw new Error('Shelby SDK not available');
    }

    // Get the default export or the first available class
    const ShelbyClass = (ShelbyModule as any).default || 
                       (ShelbyModule as any).ShelbyBlob || 
                       Object.values(ShelbyModule).find(v => typeof v === 'function');

    if (!ShelbyClass) {
      throw new Error('Could not find ShelbyBlob class');
    }

    shelby = new (ShelbyClass as any)({
      apiKey: SHELBY_API_KEY,
    });

    return shelby;
  } catch (error) {
    console.warn('⚠️ Shelby SDK initialization failed:', error);
    // Return a mock object for now
    return createMockShelby();
  }
}

// Create a mock Shelby client if SDK is not available
function createMockShelby() {
  return {
    upload: async (file: File, options: any) => {
      console.warn('Using mock Shelby SDK - uploads will not work');
      return { id: 'mock-' + Date.now() };
    },
    getDownloadUrl: async (blobId: string, options: any) => {
      return `shelby://${blobId}`;
    },
    delete: async (blobId: string, options: any) => true,
    getMetadata: async (blobId: string) => ({}),
    listBlobs: async (options: any) => [],
  };
}

// Initialize on module load
initializeShelby();

// ============================================================================
// UPLOAD FUNCTIONS
// ============================================================================

/**
 * Upload using Official Shelby SDK
 */
export async function uploadWithProgress(
  file: File,
  walletAddress: string,
  metadata: Partial<VideoMetadata> | undefined,
  onProgress: (progress: number) => void
): Promise<{ success: boolean; blobId?: string; shelbyUrl?: string; error?: string }> {
  try {
    console.log('🚀 Starting Official Shelby SDK Upload...');
    
    const shelbyClient = await getShelbyClient();
    
    // Official SDK upload call
    const result = await shelbyClient.upload(file, {
      uploader: walletAddress,
      metadata: {
        title: metadata?.title || file.name,
        description: metadata?.description || '',
        contentType: file.type,
      },
      onProgress: (p: number) => {
        const percent = p > 1 ? p : p * 100;
        onProgress(Math.round(percent));
      }
    });

    if (!result || !result.id) {
      throw new Error('Upload failed: No ID returned');
    }

    return {
      success: true,
      blobId: result.id,
      shelbyUrl: `shelby://${result.id}`,
    };

  } catch (error) {
    console.error('❌ Shelby SDK Upload Error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Upload failed',
    };
  }
}

/**
 * Get Shelby client instance
 */
async function getShelbyClient() {
  return shelby || await initializeShelby();
}

/**
 * Legacy wrapper
 */
export async function uploadVideoToShelby(
  file: File,
  walletAddress: string,
  metadata?: Partial<VideoMetadata>
) {
  return uploadWithProgress(file, walletAddress, metadata, () => {});
}

// ============================================================================
// ACCESS & UTILS
// ============================================================================

export async function getVideoStreamUrl(blobId: string, walletAddress: string): Promise<string> {
  const shelbyClient = await getShelbyClient();
  return shelbyClient.getDownloadUrl(blobId, { uploader: walletAddress });
}

export async function deleteVideoBlob(blobId: string, walletAddress: string): Promise<boolean> {
  try {
    const shelbyClient = await getShelbyClient();
    await shelbyClient.delete(blobId, { uploader: walletAddress });
    return true;
  } catch {
    return false;
  }
}

export function validateVideoFile(file: File): { valid: boolean; error?: string } {
  const MAX_SIZE = 100 * 1024 * 1024;
  const ALLOWED_TYPES = ['video/mp4', 'video/webm', 'video/quicktime'];
  if (!ALLOWED_TYPES.includes(file.type)) return { valid: false, error: 'Format not supported. Use MP4, WebM or MOV.' };
  if (file.size > MAX_SIZE) return { valid: false, error: 'File too large (max 100MB).' };
  return { valid: true };
}

export async function generateThumbnail(file: File): Promise<string> {
  return new Promise((resolve) => {
    const video = document.createElement('video');
    video.preload = 'metadata';
    video.onloadedmetadata = () => {
      video.currentTime = 1;
      const canvas = document.createElement('canvas');
      video.onseeked = () => {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        ctx?.drawImage(video, 0, 0);
        resolve(canvas.toDataURL('image/jpeg'));
      };
    };
    video.src = URL.createObjectURL(file);
  });
}

export async function getBlobMetadata(blobId: string): Promise<any> {
  try {
    const shelbyClient = await getShelbyClient();
    const metadata = await shelbyClient.getMetadata(blobId);
    return metadata;
  } catch (error) {
    console.error('Error fetching blob metadata:', error);
    return null;
  }
}

export async function listUserBlobs(walletAddress: string): Promise<any[]> {
  try {
    const shelbyClient = await getShelbyClient();
    const blobs = await shelbyClient.listBlobs({ uploader: walletAddress });
    return blobs || [];
  } catch (error) {
    console.error('Error listing user blobs:', error);
    return [];
  }
}

export async function verifyBlobAccess(blobId: string, walletAddress: string): Promise<boolean> {
  try {
    // Verify if the wallet can access this blob
    const url = await getVideoStreamUrl(blobId, walletAddress);
    return !!url;
  } catch (error) {
    console.error('Error verifying blob access:', error);
    return false;
  }
}

export async function downloadVideoBlob(blobId: string, walletAddress: string): Promise<Blob | null> {
  try {
    const url = await getVideoStreamUrl(blobId, walletAddress);
    const response = await fetch(url);
    return await response.blob();
  } catch (error) {
    console.error('Error downloading blob:', error);
    return null;
  }
}

// Default export
export default {
  uploadWithProgress,
  uploadVideoToShelby,
  getVideoStreamUrl,
  deleteVideoBlob,
  validateVideoFile,
  generateThumbnail,
  getBlobMetadata,
  listUserBlobs,
  verifyBlobAccess,
  downloadVideoBlob,
};
