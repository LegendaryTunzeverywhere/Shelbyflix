'use client';

import React, { useState, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useWallet } from '@aptos-labs/wallet-adapter-react';
import type { UploadProgress } from '@/types';
import { uploadWithProgress, validateVideoFile } from '@/lib/shelby';
import { storeVideoMetadataOnChain } from '@/lib/contract';
import { SHELBYUSD_TOKEN } from '@/lib/aptos';
import { 
  CloudArrowUpIcon,
  XMarkIcon,
  CheckCircleIcon,
  ExclamationCircleIcon,
  ShieldCheckIcon,
  FingerPrintIcon
} from '@heroicons/react/24/outline';

interface UploadFormProps {
  onSuccess?: () => void;
  onCancel?: () => void;
}

const UploadForm: React.FC<UploadFormProps> = ({ onSuccess, onCancel }) => {
  const router = useRouter();
  const { account, signAndSubmitTransaction } = useWallet();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('0');
  const [isDragging, setIsDragging] = useState(false);
  const [progress, setProgress] = useState<UploadProgress | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile) {
      validateAndSetFile(droppedFile);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      validateAndSetFile(selectedFile);
    }
  };

  const validateAndSetFile = (file: File) => {
    const validation = validateVideoFile(file);
    if (!validation.valid) {
      setError(validation.error || 'Invalid file');
      return;
    }
    setFile(file);
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!file || !title.trim() || !account) {
      setError('Please connect your wallet and complete the form');
      return;
    }

    try {
      setError(null);
      setProgress({ percent: 5, stage: 'preparing', message: 'Verifying wallet security...' });
      
      if (!signAndSubmitTransaction) {
        throw new Error('Wallet adapter not ready. Reconnect and try again.');
      }

      setProgress({ percent: 10, stage: 'uploading', message: 'Initiating Shelby Protocol stream...' });
      
      const uploadResult = await uploadWithProgress(
        file,
        account.address.toString(),
        { 
          title: title.trim(), 
          description: description.trim(),
          uploader: account.address.toString()
        },
        (p) => {
          const mappedPercent = 10 + (p * 0.75);
          setProgress({ 
            percent: Math.round(mappedPercent), 
            stage: 'uploading', 
            message: `Streaming to Shelby... ${p}%` 
          });
        }
      );

      if (!uploadResult.success || !uploadResult.blobId) {
        throw new Error(uploadResult.error || 'Shelby stream interrupted');
      }

      setProgress({ percent: 90, stage: 'processing', message: 'Finalizing metadata...' });

      // Store on-chain metadata (optional - contract deployment not required)
      try {
        await storeVideoMetadataOnChain(
          account.address.toString(),
          signAndSubmitTransaction,
          {
            videoId: uploadResult.blobId,
            title: title.trim(),
            description: description.trim(),
            shelbyUrl: uploadResult.shelbyUrl || `shelby://${uploadResult.blobId}`,
            uploader: account.address.toString(),
            requiredToken: SHELBYUSD_TOKEN,
            price: Math.floor(parseFloat(price) * 100000000),
          }
        );
      } catch (chainError) {
        console.warn('⚠️ On-chain metadata storage unavailable, but video uploaded to Shelby:', chainError);
        // Continue - Shelby storage is the primary storage
      }

      setProgress({ percent: 100, stage: 'complete', message: 'Asset Successfully Published!' });

      setTimeout(() => {
        if (onSuccess) onSuccess();
        else router.push(`/video/${uploadResult.blobId}`);
      }, 2000);

    } catch (err) {
      console.error('Publishing failed:', err);
      setError(err instanceof Error ? err.message : 'Publishing failed');
      setProgress(null);
    }
  };

  const resetForm = () => {
    setFile(null);
    setTitle('');
    setDescription('');
    setPrice('0');
    setProgress(null);
    setError(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  if (progress) {
    return (
      <div className="max-w-2xl mx-auto p-8">
        <div className="bg-white rounded-[2rem] shadow-2xl p-12 border-4 border-primary-50 relative overflow-hidden">
          <div className="absolute inset-0 pointer-events-none opacity-5 bg-[linear-gradient(transparent_0%,rgba(59,130,246,0.2)_50%,transparent_100%)] bg-[length:100%_20px] animate-[scan_2s_linear_infinite]" />
          
          <div className="text-center mb-12">
            <div className="relative inline-flex mb-8">
              <div className="absolute inset-0 bg-primary-400 rounded-full blur-2xl opacity-20 animate-pulse" />
              <div className="relative w-24 h-24 rounded-full bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center text-white shadow-xl">
                {progress.stage === 'complete' ? (
                  <CheckCircleIcon className="w-14 h-14" />
                ) : (
                  <FingerPrintIcon className="w-12 h-12 animate-pulse" />
                )}
              </div>
            </div>

            <h2 className="text-4xl font-black text-gray-900 mb-4 tracking-tighter">
              {progress.stage === 'complete' ? 'PUBLISHED' : 'PUBLISHING'}
            </h2>
            
            <div className="inline-block px-6 py-2 bg-gray-900 text-white rounded-full text-xs font-black uppercase tracking-[0.3em]">
              {progress.message}
            </div>
          </div>

          <div className="relative pt-1">
            <div className="flex mb-4 items-center justify-between">
              <div className="text-left">
                <span className="text-[10px] font-black text-primary-600 uppercase tracking-widest">Global Pool Pipeline</span>
              </div>
              <div className="text-right">
                <span className="text-2xl font-black text-gray-900">{progress.percent}%</span>
              </div>
            </div>
            <div className="overflow-hidden h-4 mb-4 text-xs flex rounded-full bg-gray-100 border-2 border-gray-50 shadow-inner">
              <div
                style={{ width: `${progress.percent}%` }}
                className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-primary-600 transition-all duration-700 ease-out relative"
              >
                <div className="absolute inset-0 opacity-30 bg-[linear-gradient(45deg,rgba(255,255,255,.2)_25%,transparent_25%,transparent_50%,rgba(255,255,255,.2)_50%,rgba(255,255,255,.2)_75%,transparent_75%,transparent)] bg-[length:15px_15px] animate-[move_1s_linear_infinite]" />
              </div>
            </div>
          </div>

          {progress.percent >= 85 && progress.stage !== 'complete' && (
            <div className="mt-12 p-6 bg-primary-50 rounded-2xl border-2 border-primary-100 flex items-center gap-5 animate-bounce">
              <div className="w-12 h-12 rounded-xl bg-primary-600 flex items-center justify-center flex-shrink-0 shadow-lg">
                <ShieldCheckIcon className="w-8 h-8 text-white" />
              </div>
              <p className="text-sm font-black text-primary-900 leading-tight">
                ACTION REQUIRED: Verify the ownership registration in your wallet popup now.
              </p>
            </div>
          )}
        </div>
        
        <style jsx>{`
          @keyframes scan { 0% { background-position: 0 -100px; } 100% { background-position: 0 500px; } }
          @keyframes move { 0% { background-position: 0 0; } 100% { background-position: 30px 0; } }
        `}</style>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <form onSubmit={handleSubmit} className="bg-white rounded-[2.5rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] border border-gray-100 overflow-hidden">
        <div className="p-10 md:p-16">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="w-2 h-2 rounded-full bg-primary-500 animate-ping" />
                <span className="text-[10px] font-black text-primary-600 uppercase tracking-[0.4em]">Asset Creation Node</span>
              </div>
              <h2 className="text-5xl font-black text-gray-900 tracking-tighter">Mint Video</h2>
            </div>
            <div className="px-6 py-3 bg-gray-50 rounded-2xl border border-gray-100">
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Network Protocol</p>
              <p className="text-sm font-bold text-gray-700">Shelby v1 + Aptos</p>
            </div>
          </div>

          <div className="grid lg:grid-cols-5 gap-16">
            <div className="lg:col-span-2">
              <div
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => fileInputRef.current?.click()}
                className={`group relative rounded-[2rem] text-center cursor-pointer 
                  transition-all duration-500 aspect-square flex flex-col items-center justify-center
                  border-4 border-dashed overflow-hidden
                  ${isDragging 
                    ? 'border-primary-500 bg-primary-50 scale-[0.98]' 
                    : 'border-gray-100 hover:border-primary-200 hover:bg-gray-50/50'
                  }`}
              >
                <input ref={fileInputRef} type="file" accept="video/mp4,video/webm,video/quicktime" onChange={handleFileSelect} className="hidden" />

                {file ? (
                  <div className="relative z-10 p-8 w-full h-full flex flex-col items-center justify-center">
                    <div className="w-24 h-24 bg-green-500 rounded-3xl flex items-center justify-center text-white shadow-2xl mb-6 transform group-hover:scale-110 transition-transform">
                      <CheckCircleIcon className="w-14 h-14" />
                    </div>
                    <p className="font-black text-gray-900 text-lg truncate w-full px-4 mb-1">{file.name}</p>
                    <p className="text-xs font-black text-gray-400 uppercase">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                ) : (
                  <>
                    <div className="w-24 h-24 bg-gray-50 rounded-[2rem] flex items-center justify-center mb-8 text-gray-200 group-hover:text-primary-500 group-hover:bg-primary-50 group-hover:shadow-inner transition-all duration-500">
                      <CloudArrowUpIcon className="w-12 h-12" />
                    </div>
                    <p className="text-2xl font-black text-gray-800 mb-2 tracking-tight">Select File</p>
                    <p className="text-[10px] font-black text-gray-300 uppercase tracking-widest">MP4 / WebM / MOV</p>
                  </>
                )}
              </div>
            </div>

            <div className="lg:col-span-3 space-y-10">
              <div className="grid gap-8">
                <div className="group">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mb-3 group-focus-within:text-primary-600 transition-colors">Video Title</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Enter a power title..."
                    className="w-full px-0 py-4 bg-transparent border-b-4 border-gray-50 focus:border-primary-500 transition-all outline-none font-black text-3xl text-gray-900 placeholder:text-gray-100"
                    required
                  />
                </div>

                <div className="group">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mb-3 group-focus-within:text-primary-600 transition-colors">Description</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                    placeholder="Provide asset details..."
                    className="w-full px-6 py-5 bg-gray-50 border-2 border-gray-50 rounded-3xl focus:border-primary-500 focus:bg-white transition-all outline-none font-bold text-gray-700 resize-none"
                  />
                </div>

                <div className="group">
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mb-3 group-focus-within:text-primary-600 transition-colors">Viewing Price</label>
                  <div className="flex items-center gap-4">
                    <div className="relative flex-1">
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        className="w-full pl-8 pr-16 py-6 bg-gray-50 border-2 border-gray-50 rounded-3xl focus:border-primary-500 focus:bg-white transition-all outline-none font-black text-4xl text-gray-900 tabular-nums"
                      />
                      <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-200 font-black text-xl">$</div>
                    </div>
                    <div className="px-6 py-6 bg-gray-900 rounded-3xl text-white font-black text-xs uppercase tracking-widest flex items-center justify-center">
                      ShelbyUSD
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="mt-16 p-8 bg-red-50 border-l-8 border-red-500 rounded-3xl flex items-center gap-6 shadow-xl animate-[shake_0.5s_ease-in-out]">
              <div className="w-12 h-12 bg-red-500 rounded-2xl flex items-center justify-center text-white flex-shrink-0 shadow-lg shadow-red-500/30">
                <ExclamationCircleIcon className="w-8 h-8" />
              </div>
              <div>
                <p className="text-[10px] font-black text-red-400 uppercase tracking-widest mb-1">Security Alert</p>
                <p className="text-lg font-black text-red-900">{error}</p>
              </div>
            </div>
          )}

          <div className="mt-16 flex flex-col md:flex-row gap-6">
            <button
              type="submit"
              disabled={!file || !title.trim() || !account}
              className="flex-[3] group relative px-10 py-8 bg-gray-900 hover:bg-primary-600 disabled:bg-gray-100 disabled:text-gray-300 text-white rounded-3xl font-black transition-all shadow-[0_20px_40px_-12px_rgba(0,0,0,0.2)] hover:shadow-primary-500/40 uppercase tracking-[0.3em] text-lg active:scale-[0.98] overflow-hidden"
            >
              <span className="relative z-10 flex items-center justify-center gap-4">
                Publish Asset
                <ShieldCheckIcon className="w-8 h-8 opacity-50" />
              </span>
              <div className="absolute inset-0 bg-primary-500 translate-y-full group-hover:translate-y-0 transition-transform duration-500" />
            </button>
            
            {onCancel && (
              <button
                type="button"
                onClick={onCancel}
                className="flex-1 px-10 py-8 border-4 border-gray-50 rounded-3xl font-black text-gray-300 hover:text-gray-900 hover:border-gray-900 transition-all uppercase tracking-widest text-sm"
              >
                Abort
              </button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
};

export default UploadForm;
